import React from "react";

function List() {
  let items = ["Pizza", "Bacon", "Burgers"];
  let listObject = (
    <ul>
      {" "}
      <li>{items[0]}</li> <li>{items[1]}</li> <li>{items[2]}</li>{" "}
    </ul>
  );

  return listObject;
}

export default List;
