//Create a react app from scratch.
//It should display 2 paragraph HTML elements.
//The paragraphs should say:
//Created by YOURNAME.
//Copyright CURRENTYEAR.
//E.g.
//Created by Angela Yu.
//Copyright 2019.

import React from "react";
import ReactDOM from "react-dom";

let rootElement = document.getElementById("root");

let name = "Daylen Mackey";
let year = 2020;

let p1 = <p>Created by {name} </p>;
let p2 = <p>Copyright {year} </p>;

let overallDiv = (
  <div>
    {p1} {p2}
  </div>
);

ReactDOM.render(overallDiv, rootElement);
